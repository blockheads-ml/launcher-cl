#!/usr/bin/env bash
# launch the cocoa app
cd "$(dirname "$0")"
./apache-callback-mac -url "http://mail.google.com"
